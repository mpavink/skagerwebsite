# Skager — website (skager.eu)

Statische website voor Skager BV, gebaseerd op het definitieve ontwerp (huisstijl K4, Jost Light).

## Structuur

- `index.html` — Home
- `diensten.html`, `aanpak.html`, `over.html`, `contact.html`
- `assets/` — logo's, favicons en `responsive.css` (mobiele laag bovenop het desktop-ontwerp)

Geen build-stap nodig: pure HTML/CSS. Lokaal bekijken kan met `python3 -m http.server` in deze map.

## Deployen op skager.eu (Cloudflare Pages)

1. Maak een GitHub-repository (bijv. `skager-website`) en push deze map.
2. Cloudflare Dashboard → Workers & Pages → Create → Pages → Connect to Git → kies de repo.
   - Build command: *(leeg laten)* · Output directory: `/`
3. Na de eerste deploy: Pages-project → Custom domains → voeg `skager.eu` (en `www.skager.eu`) toe.
4. Volg de DNS-instructies (CNAME naar `<project>.pages.dev`). SSL wordt automatisch geregeld.

Elke push naar `main` deployt daarna automatisch.

## Onderhoud met Claude Code

Open deze repo in Claude Code en geef opdrachten in gewone taal, bijvoorbeeld:
- "Werk de dienstenpagina bij: voeg een dienst X toe in dezelfde stijl."
- "Controleer alle links en de mobiele weergave."
- "Vervang het e-mailadres overal door info@skager.eu."

Zie `CLAUDE.md` voor de huisstijlregels die Claude daarbij aanhoudt.

## Open punten vóór livegang

- [ ] Contactpagina: "KvK-registratie volgt bij oprichting" — aanvullen zodra KvK-nummer bekend is.
- [ ] Overweeg een contactformulier (bijv. Cloudflare Pages Functions of Formspree) naast het mailto-adres.
